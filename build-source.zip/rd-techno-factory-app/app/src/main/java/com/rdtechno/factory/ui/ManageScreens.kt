@file:OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class, androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.rdtechno.factory.ui

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.rdtechno.factory.data.*
import com.rdtechno.factory.viewmodel.FactoryViewModel
import com.rdtechno.factory.viewmodel.ProductUi
import kotlinx.coroutines.launch
import java.util.UUID

@Composable
fun HomeScreen(onOutward: () -> Unit, onCalculator: () -> Unit, onManage: () -> Unit) {
    Scaffold(topBar = { TopAppBar(title = { Text("R D TECHNO", fontWeight = FontWeight.Black) }, actions = { IconButton(onClick = onManage) { Icon(Icons.Default.Settings, "Manage") } }) }) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("What do you want to do?", style = MaterialTheme.typography.titleMedium)
            HomeActionCard("OUTWARD", "Create factory dispatch", Icons.Default.LocalShipping, onOutward)
            HomeActionCard("CALCULATOR", "Product & manufacturing costing", Icons.Default.Calculate, onCalculator)
            Spacer(Modifier.weight(1f))
            Text("Offline • Local database • R D Techno", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun HomeActionCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().heightIn(min = 120.dp).clickable(onClick = onClick)) {
        Row(Modifier.fillMaxSize().padding(20.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(18.dp)) {
            Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.primary) { Icon(icon, null, Modifier.padding(14.dp).size(30.dp), tint = MaterialTheme.colorScheme.onPrimary) }
            Column { Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
    }
}

@Composable
fun ManageScreen(onBack: () -> Unit, onInventory: () -> Unit, onMaterials: () -> Unit, onLocations: () -> Unit, onData: () -> Unit) {
    Scaffold(topBar = { SimpleTopBar("Manage", onBack) }) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Spacer(Modifier.height(4.dp)); ScreenTitle("Manage R D Techno", "Everything important stays one tap away.") }
            item { ManageRow(Icons.Default.Inventory2, "Inventory", "Add, edit, delete products and images", onInventory) }
            item { ManageRow(Icons.Default.Science, "Materials", "Material names and ₹/kg rates", onMaterials) }
            item { ManageRow(Icons.Default.LocationOn, "Locations", "Baddi, Mohali and future locations", onLocations) }
            item { ManageRow(Icons.Default.Backup, "Data", "Backup, restore and export", onData) }
        }
    }
}

@Composable
private fun ManageRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.secondary)
            Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Bold); Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            Text("›", style = MaterialTheme.typography.headlineSmall)
        }
    }
}

@Composable
fun InventoryScreen(vm: FactoryViewModel, onBack: () -> Unit, onProduct: (String) -> Unit, onNewProduct: () -> Unit) {
    val products by vm.products.collectAsStateWithLifecycle()
    val categories by vm.categories.collectAsStateWithLifecycle()
    var query by remember { mutableStateOf("") }
    var category by remember { mutableStateOf<String?>(null) }
    val filtered = products.filter { p -> (category == null || p.product.categoryId == category) && (query.isBlank() || p.product.name.contains(query, true) || p.material?.name?.contains(query, true) == true) }

    Scaffold(topBar = { SimpleTopBar("Inventory", onBack, actions = { IconButton(onClick = onNewProduct) { Icon(Icons.Default.Add, "Add product") } }) }, floatingActionButton = { ExtendedFloatingActionButton(onClick = onNewProduct, icon = { Icon(Icons.Default.Add, null) }, text = { Text("Add Product") }) }) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth().padding(12.dp), singleLine = true, label = { Text("Search products") }, leadingIcon = { Icon(Icons.Default.Search, null) })
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(category == null, { category = null }, { Text("All") })
                categories.filter { it.active }.forEach { c -> FilterChip(category == c.id, { category = c.id }, { Text(c.name.removeSuffix(" Products")) }) }
            }
            Text("${filtered.size} products", Modifier.padding(horizontal = 16.dp, vertical = 8.dp), style = MaterialTheme.typography.labelMedium)
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(filtered, key = { it.product.id }) { p -> ProductListRow(p, onClick = { onProduct(p.product.id) }) }
                item { Spacer(Modifier.height(80.dp)) }
            }
        }
    }
}

@Composable
fun ProductListRow(p: ProductUi, onClick: () -> Unit, trailing: @Composable (() -> Unit)? = null) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ProductImage(p.product.imageRef, Modifier.size(64.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) { Text(p.product.name, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)); if (!p.product.active) AssistChip({}, { Text("Inactive") }, enabled = false) }
                Text(listOfNotNull(p.category?.name, p.material?.name).joinToString(" • ").ifBlank { "No material set" }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (p.product.materialWeightG != null || p.product.labourCost != null) Text("${p.product.materialWeightG?.let { "${trimNum(it)} g" } ?: "—"}  •  ₹${"%.2f".format(p.totalCost)}/pc", style = MaterialTheme.typography.bodySmall)
            }
            trailing?.invoke() ?: Text("›", style = MaterialTheme.typography.headlineSmall)
        }
    }
}

@Composable
fun ProductEditorScreen(vm: FactoryViewModel, productId: String, onBack: () -> Unit) {
    val context = LocalContext.current
    val products by vm.products.collectAsStateWithLifecycle()
    val categories by vm.categories.collectAsStateWithLifecycle()
    val materials by vm.materials.collectAsStateWithLifecycle()
    val existing = products.firstOrNull { it.product.id == productId }?.product
    val isNew = productId == "new"

    var name by remember(productId) { mutableStateOf("") }
    var categoryId by remember(productId) { mutableStateOf("CAT-PLASTIC") }
    var materialId by remember(productId) { mutableStateOf<String?>(null) }
    var weight by remember(productId) { mutableStateOf("") }
    var labour by remember(productId) { mutableStateOf("") }
    var notes by remember(productId) { mutableStateOf("") }
    var active by remember(productId) { mutableStateOf(true) }
    var imageRef by remember(productId) { mutableStateOf<String?>(null) }
    var initialized by remember(productId) { mutableStateOf(isNew) }
    var showDelete by remember { mutableStateOf(false) }

    LaunchedEffect(existing?.id) {
        if (!isNew && existing != null && !initialized) {
            name = existing.name; categoryId = existing.categoryId; materialId = existing.materialId
            weight = existing.materialWeightG?.let(::trimNum).orEmpty(); labour = existing.labourCost?.let(::trimNum).orEmpty()
            notes = existing.notes; active = existing.active; imageRef = existing.imageRef; initialized = true
        }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> uri?.let { ImageStorage.copyIntoApp(context, it)?.let { path -> ImageStorage.deleteIfManaged(context, imageRef); imageRef = path } } }
    val selectedMaterial = materials.firstOrNull { it.id == materialId }
    val materialCost = ((weight.toDoubleOrNull() ?: 0.0) / 1000.0) * (selectedMaterial?.ratePerKg ?: 0.0)
    val total = materialCost + (labour.toDoubleOrNull() ?: 0.0)

    Scaffold(topBar = { SimpleTopBar(if (isNew) "Add Product" else "Product", onBack) }) { pad ->
        if (!isNew && existing == null && !initialized) { Box(Modifier.fillMaxSize().padding(pad), contentAlignment = Alignment.Center) { CircularProgressIndicator() } }
        else LazyColumn(Modifier.fillMaxSize().padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    ProductImage(imageRef, Modifier.size(110.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { picker.launch("image/*") }) { Icon(Icons.Default.AddPhotoAlternate, null); Spacer(Modifier.width(6.dp)); Text(if (imageRef == null) "Add Image" else "Change Image") }
                        if (imageRef != null) TextButton(onClick = { ImageStorage.deleteIfManaged(context, imageRef); imageRef = null }) { Text("Remove Image") }
                    }
                }
            }
            item { OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text("Product Name") }, singleLine = true) }
            item {
                Text("Category", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { categories.filter { it.active }.forEach { c -> FilterChip(categoryId == c.id, { categoryId = c.id }, { Text(c.name) }) } }
            }
            item {
                Text("Material", fontWeight = FontWeight.SemiBold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    FilterChip(materialId == null, { materialId = null }, { Text("Not set") })
                    materials.filter { it.active }.forEach { m -> FilterChip(materialId == m.id, { materialId = m.id }, { Text("${m.name} • ₹${trimNum(m.ratePerKg)}/kg") }) }
                }
            }
            item { OutlinedTextField(weight, { weight = numeric(it) }, Modifier.fillMaxWidth(), label = { Text("Material Weight (g)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true) }
            item { OutlinedTextField(labour, { labour = numeric(it) }, Modifier.fillMaxWidth(), label = { Text("Labour Cost / Piece (₹)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true) }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Metric("Material cost", "₹${"%.2f".format(materialCost)}", Modifier.weight(1f)); Metric("Total / pc", "₹${"%.2f".format(total)}", Modifier.weight(1f))
                }
            }
            item { OutlinedTextField(notes, { notes = it }, Modifier.fillMaxWidth(), label = { Text("Notes") }, minLines = 2) }
            item { Row(verticalAlignment = Alignment.CenterVertically) { Switch(active, { active = it }); Spacer(Modifier.width(10.dp)); Text(if (active) "Active product" else "Inactive / archived") } }
            item {
                Button(onClick = {
                    if (name.trim().isBlank()) { vm.showMessage("Product name is required."); return@Button }
                    val id = if (isNew) vm.newProductId() else existing!!.id
                    vm.saveProduct(ProductEntity(id=id, name=name.trim(), categoryId=categoryId, imageRef=imageRef, active=active, materialId=materialId, materialWeightG=weight.toDoubleOrNull(), labourCost=labour.toDoubleOrNull(), notes=notes.trim(), legacyDriveFileId=existing?.legacyDriveFileId, createdAtMs=existing?.createdAtMs ?: System.currentTimeMillis()), onSaved = { if (isNew) onBack() })
                }, Modifier.fillMaxWidth().height(52.dp)) { Text("SAVE PRODUCT") }
            }
            if (!isNew) item { OutlinedButton(onClick = { showDelete = true }, Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)) { Icon(Icons.Default.Delete, null); Spacer(Modifier.width(6.dp)); Text("Delete Product") } }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }

    if (showDelete && existing != null) AlertDialog(onDismissRequest = { showDelete = false }, title = { Text("Delete ${existing.name}?") }, text = { Text("This removes it from Product Master. Old Outward and Order records will keep the saved product name, so history remains readable.") }, confirmButton = { Button(onClick = { showDelete = false; vm.deleteProduct(existing, onBack) }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) { Text("Delete") } }, dismissButton = { TextButton(onClick = { showDelete = false }) { Text("Cancel") } })
}

@Composable
fun MaterialsScreen(vm: FactoryViewModel, onBack: () -> Unit) {
    val materials by vm.materials.collectAsStateWithLifecycle()
    var editing by remember { mutableStateOf<MaterialEntity?>(null) }
    var adding by remember { mutableStateOf(false) }
    Scaffold(topBar = { SimpleTopBar("Materials", onBack, actions = { IconButton(onClick = { adding = true }) { Icon(Icons.Default.Add, "Add") } }) }) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item { Text("Changing a ₹/kg rate updates every linked product calculation automatically.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(materials, key = { it.id }) { m -> Card(Modifier.fillMaxWidth().clickable { editing = m }) { Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(m.name, fontWeight = FontWeight.Bold); Text("₹${trimNum(m.ratePerKg)} / kg") }; Icon(Icons.Default.Edit, null) } } }
        }
    }
    if (adding || editing != null) MaterialDialog(editing, onDismiss = { adding = false; editing = null }, onSave = { id, name, rate -> vm.saveMaterial(id, name, rate); adding = false; editing = null })
}

@Composable
private fun MaterialDialog(item: MaterialEntity?, onDismiss: () -> Unit, onSave: (String?, String, Double) -> Unit) {
    var name by remember(item?.id) { mutableStateOf(item?.name.orEmpty()) }; var rate by remember(item?.id) { mutableStateOf(item?.ratePerKg?.let(::trimNum).orEmpty()) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (item == null) "Add Material" else "Edit Material") }, text = { Column(verticalArrangement = Arrangement.spacedBy(10.dp)) { OutlinedTextField(name,{name=it},label={Text("Material name")}); OutlinedTextField(rate,{rate=numeric(it)},label={Text("Rate ₹/kg")}, keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal)) } }, confirmButton = { Button(onClick = { rate.toDoubleOrNull()?.let { onSave(item?.id,name,it) } }) { Text("Save") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

@Composable
fun LocationsScreen(vm: FactoryViewModel, onBack: () -> Unit) {
    val locations by vm.locations.collectAsStateWithLifecycle(); var editing by remember { mutableStateOf<LocationEntity?>(null) }; var adding by remember { mutableStateOf(false) }
    Scaffold(topBar = { SimpleTopBar("Locations", onBack, actions = { IconButton(onClick = { adding = true }) { Icon(Icons.Default.Add, "Add") } }) }) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(locations, key = { it.id }) { l -> Card(Modifier.fillMaxWidth().clickable { editing = l }) { Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(l.name, fontWeight=FontWeight.Bold); Text(listOf(l.companyName,l.phone).filter{it.isNotBlank()}.joinToString(" • ").ifBlank{"Tap to add details"}, style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant) }; Icon(Icons.Default.Edit,null) } } }
        }
    }
    if (adding || editing != null) LocationDialog(editing, newId = vm.newLocationId(), onDismiss = { adding=false;editing=null }, onSave = { vm.saveLocation(it); adding=false;editing=null })
}

@Composable
private fun LocationDialog(item: LocationEntity?, newId: String, onDismiss: () -> Unit, onSave: (LocationEntity) -> Unit) {
    var name by remember(item?.id) { mutableStateOf(item?.name.orEmpty()) }; var company by remember(item?.id) { mutableStateOf(item?.companyName.orEmpty()) }; var address by remember(item?.id) { mutableStateOf(item?.address.orEmpty()) }; var contact by remember(item?.id) { mutableStateOf(item?.contactName.orEmpty()) }; var phone by remember(item?.id) { mutableStateOf(item?.phone.orEmpty()) }; var notes by remember(item?.id) { mutableStateOf(item?.notes.orEmpty()) }; var active by remember(item?.id) { mutableStateOf(item?.active ?: true) }
    AlertDialog(onDismissRequest=onDismiss,title={Text(if(item==null)"Add Location" else "Edit Location")},text={LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){ item{OutlinedTextField(name,{name=it},label={Text("Location name")})}; item{OutlinedTextField(company,{company=it},label={Text("Company / customer")})}; item{OutlinedTextField(address,{address=it},label={Text("Address")})}; item{OutlinedTextField(contact,{contact=it},label={Text("Contact person")})}; item{OutlinedTextField(phone,{phone=it},label={Text("Phone")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Phone))}; item{OutlinedTextField(notes,{notes=it},label={Text("Notes")})}; item{Row(verticalAlignment=Alignment.CenterVertically){Switch(active,{active=it});Spacer(Modifier.width(8.dp));Text("Active")}} }},confirmButton={Button(onClick={if(name.isNotBlank())onSave(LocationEntity(item?.id?:newId,name.trim(),company.trim(),address.trim(),contact.trim(),phone.trim(),notes.trim(),active))}){Text("Save")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})
}

@Composable
fun DataScreen(vm: FactoryViewModel, onBack: () -> Unit) {
    val context = LocalContext.current; val scope = rememberCoroutineScope(); var backupText by remember { mutableStateOf<String?>(null) }; var pendingRestore by remember { mutableStateOf<String?>(null) }
    val backupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri -> if(uri!=null && backupText!=null) runCatching { context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(backupText!!) } }.onSuccess { vm.showMessage("Backup saved.") } }
    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if(uri!=null) pendingRestore = runCatching { context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } }.getOrNull() }
    var exportText by remember { mutableStateOf<String?>(null) }; var exportName by remember { mutableStateOf("export.csv") }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri -> if(uri!=null && exportText!=null) runCatching { context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(exportText!!) } }.onSuccess { vm.showMessage("Export saved.") } }

    Scaffold(topBar = { SimpleTopBar("Data", onBack) }) { pad -> LazyColumn(Modifier.fillMaxSize().padding(pad), contentPadding=PaddingValues(14.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
        item { ScreenTitle("Backup & Restore", "Portable offline backup includes database and custom product images.") }
        item { DataAction(Icons.Default.Backup,"Backup Data","Save a full R D Techno backup") { scope.launch { backupText=BackupManager.createBackup(context,vm.db); backupLauncher.launch("rd-techno-backup.json") } } }
        item { DataAction(Icons.Default.Restore,"Restore Backup","Replaces current local data only after confirmation") { restoreLauncher.launch(arrayOf("application/json","text/plain","*/*")) } }
        item { Spacer(Modifier.height(8.dp)); ScreenTitle("Export") }
        item { DataAction(Icons.Default.TableView,"Products CSV","Product master and costing") { scope.launch { exportText=BackupManager.productsCsv(vm.db); exportName="rd-techno-products.csv"; exportLauncher.launch(exportName) } } }
        item { DataAction(Icons.Default.TableView,"Outward CSV","Complete outward line history") { scope.launch { exportText=BackupManager.outwardsCsv(vm.db); exportName="rd-techno-outward.csv"; exportLauncher.launch(exportName) } } }
    } }
    if(pendingRestore!=null) AlertDialog(onDismissRequest={pendingRestore=null},title={Text("Restore backup?")},text={Text("This will replace the current local database on this phone. Keep a current backup first if you may need to undo it.")},confirmButton={Button(onClick={val text=pendingRestore!!;pendingRestore=null;scope.launch{runCatching{BackupManager.restoreBackup(context,vm.db,text)}.onSuccess{vm.showMessage("Backup restored.")}.onFailure{vm.showMessage("Restore failed: ${it.message}")}}},colors=ButtonDefaults.buttonColors(containerColor=MaterialTheme.colorScheme.error)){Text("Restore")}},dismissButton={TextButton(onClick={pendingRestore=null}){Text("Cancel")}})
}

@Composable
private fun DataAction(icon: androidx.compose.ui.graphics.vector.ImageVector,title:String,subtitle:String,onClick:()->Unit){Card(Modifier.fillMaxWidth().clickable(onClick=onClick)){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(12.dp)){Icon(icon,null);Column(Modifier.weight(1f)){Text(title,fontWeight=FontWeight.Bold);Text(subtitle,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};Text("›",style=MaterialTheme.typography.headlineSmall)}}}

private fun numeric(s:String):String=s.filterIndexed{index,c->c.isDigit()||(c=='.'&&!s.take(index).contains('.'))}
fun trimNum(v:Double):String=if(v%1.0==0.0)v.toInt().toString() else "%.3f".format(v).trimEnd('0').trimEnd('.')
