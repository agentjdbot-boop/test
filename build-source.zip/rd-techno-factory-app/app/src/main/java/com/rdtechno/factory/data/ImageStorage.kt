package com.rdtechno.factory.data

import android.content.Context
import android.net.Uri
import java.io.File
import java.util.UUID

object ImageStorage {
    fun copyIntoApp(context: Context, uri: Uri): String? = runCatching {
        val mime = context.contentResolver.getType(uri).orEmpty()
        val ext = when {
            mime.contains("png") -> "png"
            mime.contains("webp") -> "webp"
            else -> "jpg"
        }
        val dir = File(context.filesDir, "product_images").apply { mkdirs() }
        val target = File(dir, "product_${UUID.randomUUID()}.$ext")
        context.contentResolver.openInputStream(uri)!!.use { input -> target.outputStream().use { input.copyTo(it) } }
        target.absolutePath
    }.getOrNull()

    fun deleteIfManaged(context: Context, imageRef: String?) {
        if (imageRef.isNullOrBlank() || imageRef.startsWith("res:")) return
        runCatching {
            val file = File(imageRef)
            if (file.canonicalPath.startsWith(File(context.filesDir, "product_images").canonicalPath)) file.delete()
        }
    }
}
