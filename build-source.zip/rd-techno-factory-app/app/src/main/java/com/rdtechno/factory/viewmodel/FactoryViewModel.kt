package com.rdtechno.factory.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.rdtechno.factory.RDTechnoApplication
import com.rdtechno.factory.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.util.UUID

class FactoryViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as RDTechnoApplication
    val db = app.database
    private val repo = app.repository

    val categories = repo.categories.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val materials = repo.materials.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val locations = repo.locations.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val products: StateFlow<List<ProductUi>> = combine(repo.products, repo.materials, repo.categories) { products, materials, categories ->
        val materialMap = materials.associateBy { it.id }
        val categoryMap = categories.associateBy { it.id }
        products.map { p ->
            val m = materialMap[p.materialId]
            val materialCost = ((p.materialWeightG ?: 0.0) / 1000.0) * (m?.ratePerKg ?: 0.0)
            ProductUi(p, categoryMap[p.categoryId], m, materialCost, materialCost + (p.labourCost ?: 0.0))
        }.sortedBy { it.product.name.lowercase() }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val outwardHistory: StateFlow<List<OutwardSummary>> = combine(repo.outwards, repo.outwardLines, repo.locations) { outwards, lines, locations ->
        val lineMap = lines.groupBy { it.outwardId }
        val locMap = locations.associateBy { it.id }
        outwards.map { o -> OutwardSummary(o, locMap[o.locationId]?.name ?: if (o.locationId == null) "Legacy / not saved" else "Deleted location", lineMap[o.id].orEmpty()) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val orderHistory: StateFlow<List<OrderSummary>> = combine(repo.orders, repo.orderLines, repo.orderRequirements, repo.locations) { orders, lines, reqs, locs ->
        val lineMap = lines.groupBy { it.orderId }
        val reqMap = reqs.groupBy { it.orderLineId }
        val locMap = locs.associateBy { it.id }
        orders.map { o ->
            OrderSummary(o, lineMap[o.id].orEmpty().sortedBy { it.priority }.map { line ->
                OrderLineSummary(line, reqMap[line.id].orEmpty().map { r -> OrderRequirementSummary(locMap[r.locationId]?.name ?: "Deleted location", r.quantity) })
            })
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _outwardDraft = MutableStateFlow(OutwardDraft())
    val outwardDraft: StateFlow<OutwardDraft> = _outwardDraft.asStateFlow()

    private val _orderDraft = MutableStateFlow(OrderDraft())
    val orderDraft: StateFlow<OrderDraft> = _orderDraft.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    init {
        viewModelScope.launch {
            runCatching { SeedImporter.seedIfNeeded(app, db) }
                .onFailure { _message.value = "Initial data import failed: ${it.message}" }
        }
    }

    fun consumeMessage() { _message.value = null }
    fun showMessage(value: String) { _message.value = value }

    fun startOutward(locationId: String) {
        _outwardDraft.value = OutwardDraft(selectedLocationId = locationId)
    }
    fun setOutwardLocation(locationId: String) { _outwardDraft.update { it.copy(selectedLocationId = locationId) } }
    fun setOutwardDate(value: String) { _outwardDraft.update { it.copy(date = value) } }
    fun setOutwardVehicle(value: String) { _outwardDraft.update { it.copy(vehicle = value) } }
    fun setOutwardNotes(value: String) { _outwardDraft.update { it.copy(notes = value) } }
    fun addToOutward(product: ProductUi) {
        _outwardDraft.update { d ->
            val existing = d.cart[product.product.id]
            d.copy(cart = d.cart + (product.product.id to (existing ?: DraftCartLine(product.product.id, product.product.name, 0, 0))))
        }
    }
    fun changeOutwardQuantity(productId: String, quantity: Int) { _outwardDraft.update { d -> d.copy(cart = d.cart.mapValues { if (it.key == productId) it.value.copy(quantity = quantity.coerceAtLeast(0)) else it.value }) } }
    fun changeOutwardBags(productId: String, bags: Int) { _outwardDraft.update { d -> d.copy(cart = d.cart.mapValues { if (it.key == productId) it.value.copy(bags = bags.coerceAtLeast(0)) else it.value }) } }
    fun removeOutwardItem(productId: String) { _outwardDraft.update { it.copy(cart = it.cart - productId) } }
    fun clearOutwardDraft() { _outwardDraft.value = OutwardDraft() }

    fun saveOutward(onSaved: (String) -> Unit) = viewModelScope.launch {
        val d = _outwardDraft.value
        if (d.selectedLocationId.isNullOrBlank()) { _message.value = "Select a location first."; return@launch }
        if (d.cart.values.none { it.quantity > 0 }) { _message.value = "Add at least one product with quantity."; return@launch }
        runCatching {
            repo.saveOutward(
                date = d.date, locationId = d.selectedLocationId, vehicle = d.vehicle, notes = d.notes,
                cart = d.cart.values.map { CartLineInput(it.productId, it.productName, it.quantity, it.bags) }
            )
        }.onSuccess { id -> _message.value = "Outward saved."; clearOutwardDraft(); onSaved(id) }
            .onFailure { _message.value = "Could not save outward: ${it.message}" }
    }

    fun deleteOutward(id: String) = viewModelScope.launch { runCatching { repo.deleteOutward(id) }.onSuccess { _message.value = "Outward deleted." }.onFailure { _message.value = it.message } }

    fun startOrder() { _orderDraft.value = OrderDraft() }
    fun setOrderDate(v: String) { _orderDraft.update { it.copy(date = v) } }
    fun setOrderNotes(v: String) { _orderDraft.update { it.copy(notes = v) } }
    fun addToOrder(product: ProductUi) {
        _orderDraft.update { d ->
            if (d.lines.containsKey(product.product.id)) d else d.copy(lines = d.lines + (product.product.id to OrderDraftLine(product.product.id, product.product.name, product.material?.name.orEmpty(), d.lines.size + 1, emptyMap())))
        }
    }
    fun removeOrderLine(productId: String) { _orderDraft.update { d -> d.copy(lines = d.lines - productId) } }
    fun setOrderRequirement(productId: String, locationId: String, qty: Int) { _orderDraft.update { d -> d.copy(lines = d.lines.mapValues { (key, line) -> if (key == productId) line.copy(requirements = line.requirements + (locationId to qty.coerceAtLeast(0))) else line }) } }
    fun moveOrder(productId: String, delta: Int) {
        _orderDraft.update { d ->
            val ordered = d.lines.values.sortedBy { it.priority }.toMutableList()
            val index = ordered.indexOfFirst { it.productId == productId }
            val target = (index + delta).coerceIn(0, ordered.lastIndex.coerceAtLeast(0))
            if (index < 0 || index == target) d else {
                val item = ordered.removeAt(index); ordered.add(target, item)
                d.copy(lines = ordered.mapIndexed { i, line -> line.copy(priority = i + 1) }.associateBy { it.productId })
            }
        }
    }
    fun saveOrder(onSaved: (String) -> Unit) = viewModelScope.launch {
        val d = _orderDraft.value
        if (d.lines.isEmpty()) { _message.value = "Add at least one product."; return@launch }
        runCatching { repo.saveOrder(d.date, d.notes, d.lines.values.map { OrderLineInput(it.productId, it.productName, it.materialName, it.priority, it.requirements) }) }
            .onSuccess { _message.value = "Order saved."; startOrder(); onSaved(it) }
            .onFailure { _message.value = "Could not save order: ${it.message}" }
    }
    fun deleteOrder(id:String)=viewModelScope.launch { runCatching { repo.deleteOrder(id) }.onSuccess { _message.value="Order deleted." }.onFailure { _message.value=it.message } }

    fun saveProduct(product: ProductEntity, onSaved: () -> Unit = {}) = viewModelScope.launch {
        runCatching { repo.saveProduct(product) }.onSuccess { _message.value = "Product saved."; onSaved() }.onFailure { _message.value = "Could not save product: ${it.message}" }
    }
    fun newProductId(): String = "P-${UUID.randomUUID().toString().take(8).uppercase()}"
    fun deleteProduct(product: ProductEntity, onDeleted: () -> Unit = {}) = viewModelScope.launch {
        runCatching { repo.deleteProduct(product.id) }.onSuccess { ImageStorage.deleteIfManaged(app, product.imageRef); _message.value = "Product deleted. Historical records are preserved."; onDeleted() }.onFailure { _message.value = "Could not delete product: ${it.message}" }
    }

    fun saveMaterial(id: String?, name: String, rate: Double, active: Boolean = true) = viewModelScope.launch {
        val clean=name.trim(); if(clean.isBlank()){_message.value="Material name is required.";return@launch}
        runCatching { repo.saveMaterial(MaterialEntity(id ?: "MAT-${UUID.randomUUID().toString().take(8).uppercase()}", clean, rate.coerceAtLeast(0.0), active)) }
            .onSuccess { _message.value="Material saved." }.onFailure { _message.value="Could not save material: ${it.message}" }
    }

    fun saveLocation(location: LocationEntity) = viewModelScope.launch { runCatching { repo.saveLocation(location) }.onSuccess { _message.value="Location saved." }.onFailure { _message.value="Could not save location: ${it.message}" } }
    fun newLocationId():String="LOC-${UUID.randomUUID().toString().take(8).uppercase()}"
}

data class ProductUi(val product: ProductEntity, val category: ProductCategoryEntity?, val material: MaterialEntity?, val materialCost: Double, val totalCost: Double)
data class DraftCartLine(val productId:String,val productName:String,val quantity:Int,val bags:Int)
data class OutwardDraft(val selectedLocationId:String?=null,val date:String=LocalDate.now().toString(),val vehicle:String="",val notes:String="",val cart:Map<String,DraftCartLine> = emptyMap())
data class OutwardSummary(val outward:OutwardEntity,val locationName:String,val lines:List<OutwardLineEntity>)
data class OrderDraftLine(val productId:String,val productName:String,val materialName:String,val priority:Int,val requirements:Map<String,Int>)
data class OrderDraft(val date:String=LocalDate.now().toString(),val notes:String="",val lines:Map<String,OrderDraftLine> = emptyMap())
data class OrderRequirementSummary(val locationName:String,val quantity:Int)
data class OrderLineSummary(val line:OrderLineEntity,val requirements:List<OrderRequirementSummary>)
data class OrderSummary(val order:OrderEntity,val lines:List<OrderLineSummary>)

class FactoryViewModelFactory(private val app: Application) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = FactoryViewModel(app) as T
}
