package com.rdtechno.factory

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rdtechno.factory.ui.RDTechnoApp
import com.rdtechno.factory.ui.RDTechnoTheme
import com.rdtechno.factory.viewmodel.FactoryViewModel
import com.rdtechno.factory.viewmodel.FactoryViewModelFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            RDTechnoTheme {
                val vm: FactoryViewModel = viewModel(factory = FactoryViewModelFactory(application))
                val message by vm.message.collectAsState()
                LaunchedEffect(message) {
                    message?.let {
                        Toast.makeText(this@MainActivity, it, Toast.LENGTH_SHORT).show()
                        vm.consumeMessage()
                    }
                }
                RDTechnoApp(vm)
            }
        }
    }
}
