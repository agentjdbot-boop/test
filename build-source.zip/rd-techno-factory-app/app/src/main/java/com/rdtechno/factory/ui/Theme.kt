package com.rdtechno.factory.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val RDColors = lightColorScheme(
    primary = Color(0xFF22272B),
    onPrimary = Color.White,
    secondary = Color(0xFFB87919),
    onSecondary = Color.White,
    background = Color(0xFFF4F0E7),
    onBackground = Color(0xFF1D2225),
    surface = Color(0xFFFFFCF7),
    onSurface = Color(0xFF1D2225),
    surfaceVariant = Color(0xFFE9E3D8),
    outline = Color(0xFF81796D)
)

@Composable
fun RDTechnoTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = RDColors, content = content)
}
