@file:OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.rdtechno.factory.ui

import android.content.Intent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.rdtechno.factory.viewmodel.FactoryViewModel
import java.time.LocalDate

@Composable
fun OrdersScreen(vm:FactoryViewModel,onBack:()->Unit,onNew:()->Unit){
    val history by vm.orderHistory.collectAsStateWithLifecycle();var deleteId by remember{mutableStateOf<String?>(null)}
    Scaffold(topBar={SimpleTopBar("Orders",onBack)},floatingActionButton={ExtendedFloatingActionButton(onClick=onNew,icon={Icon(Icons.Default.Add,null)},text={Text("New Order")})}){pad->LazyColumn(Modifier.fillMaxSize().padding(pad),contentPadding=PaddingValues(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
        item{ScreenTitle("Order Management","Requirements use the same Product Master as Outward.")}
        items(history,key={it.order.id}){o->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){Row(verticalAlignment=Alignment.CenterVertically){Text(o.order.date,Modifier.weight(1f),fontWeight=FontWeight.Bold);IconButton(onClick={deleteId=o.order.id}){Icon(Icons.Default.Delete,null)}};o.lines.take(5).forEach{l->Text("${l.line.priority}. ${l.line.productNameSnapshot} — ${l.requirements.joinToString{"${it.locationName} ${it.quantity}"}}",style=MaterialTheme.typography.bodySmall)};if(o.lines.size>5)Text("+ ${o.lines.size-5} more",style=MaterialTheme.typography.labelMedium)}}}
        item{Spacer(Modifier.height(80.dp))}
    }}
    if(deleteId!=null)AlertDialog(onDismissRequest={deleteId=null},title={Text("Delete order?")},text={Text("This removes this order sheet from history.")},confirmButton={Button(onClick={val id=deleteId!!;deleteId=null;vm.deleteOrder(id)},colors=ButtonDefaults.buttonColors(containerColor=MaterialTheme.colorScheme.error)){Text("Delete")}},dismissButton={TextButton(onClick={deleteId=null}){Text("Cancel")}})
}

@Composable
fun OrderProductBrowserScreen(vm:FactoryViewModel,onBack:()->Unit,onCart:()->Unit){
    val products by vm.products.collectAsStateWithLifecycle();val draft by vm.orderDraft.collectAsStateWithLifecycle();var query by remember{mutableStateOf("")}
    val filtered=products.filter{it.product.active&&(query.isBlank()||it.product.name.contains(query,true))}
    Scaffold(topBar={SimpleTopBar("Add Order Products",onBack)},bottomBar={Surface(shadowElevation=6.dp){Button(onClick=onCart, enabled=draft.lines.isNotEmpty(), modifier=Modifier.fillMaxWidth().padding(12.dp).height(50.dp)){Text("ORDER CART (${draft.lines.size})")}}}){pad->Column(Modifier.fillMaxSize().padding(pad)){OutlinedTextField(query,{query=it},Modifier.fillMaxWidth().padding(12.dp),label={Text("Search product")},leadingIcon={Icon(Icons.Default.Search,null)},singleLine=true);LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){items(filtered,key={it.product.id}){p->ProductListRow(p,onClick={vm.addToOrder(p)},trailing={if(draft.lines.containsKey(p.product.id))AssistChip({}, {Text("Added")}, enabled=false)else Button(onClick={vm.addToOrder(p)}){Text("ADD")}})}}}}
}

@Composable
fun OrderCartScreen(vm:FactoryViewModel,onBack:()->Unit,onSaved:(String)->Unit){
    val draft by vm.orderDraft.collectAsStateWithLifecycle();val locations by vm.locations.collectAsStateWithLifecycle()
    Scaffold(topBar={SimpleTopBar("New Order",onBack)},bottomBar={Surface(shadowElevation=6.dp){Button(onClick={vm.saveOrder(onSaved)}, enabled=draft.lines.isNotEmpty(), modifier=Modifier.fillMaxWidth().padding(12.dp).height(50.dp)){Icon(Icons.Default.Save,null);Spacer(Modifier.width(6.dp));Text("SAVE ORDER")}}}){pad->LazyColumn(Modifier.fillMaxSize().padding(pad),contentPadding=PaddingValues(12.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        item{OutlinedTextField(draft.date,{vm.setOrderDate(it)},Modifier.fillMaxWidth(),label={Text("Date (YYYY-MM-DD)")},singleLine=true);Spacer(Modifier.height(8.dp));OutlinedTextField(draft.notes,{vm.setOrderNotes(it)},Modifier.fillMaxWidth(),label={Text("Notes")})}
        items(draft.lines.values.sortedBy{it.priority},key={it.productId}){line->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
            Row(verticalAlignment=Alignment.CenterVertically){Text("${line.priority}. ${line.productName}",Modifier.weight(1f),fontWeight=FontWeight.Bold);IconButton(onClick={vm.moveOrder(line.productId,-1)}){Icon(Icons.Default.KeyboardArrowUp,null)};IconButton(onClick={vm.moveOrder(line.productId,1)}){Icon(Icons.Default.KeyboardArrowDown,null)};IconButton(onClick={vm.removeOrderLine(line.productId)}){Icon(Icons.Default.Delete,null)}}
            if(line.materialName.isNotBlank())Text("Material: ${line.materialName}",style=MaterialTheme.typography.bodySmall)
            locations.filter{it.active}.forEach{loc->OutlinedTextField((line.requirements[loc.id]?:0).toString(),{vm.setOrderRequirement(line.productId,loc.id,it.toIntOrNull()?:0)},Modifier.fillMaxWidth(),label={Text("${loc.name} requirement")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),singleLine=true)}
            Text("Total requirement: ${line.requirements.values.sum()}",fontWeight=FontWeight.SemiBold)
        }}}
        item{Spacer(Modifier.height(70.dp))}
    }}
}

@Composable
fun CalculatorScreen(vm:FactoryViewModel,onBack:()->Unit,onProduct:(String)->Unit,onMaterials:()->Unit){
    val products by vm.products.collectAsStateWithLifecycle();var query by remember{mutableStateOf("")};val plastic=products.filter{it.product.active&&it.product.categoryId=="CAT-PLASTIC"&&(query.isBlank()||it.product.name.contains(query,true)||it.material?.name?.contains(query,true)==true)}
    Scaffold(topBar={SimpleTopBar("Calculator",onBack,actions={TextButton(onClick=onMaterials){Text("Materials")}})}){pad->Column(Modifier.fillMaxSize().padding(pad)){OutlinedTextField(query,{query=it},Modifier.fillMaxWidth().padding(12.dp),label={Text("Search product or material")},leadingIcon={Icon(Icons.Default.Search,null)},singleLine=true);LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){item{ScreenTitle("Injection Moulding","Tap a product to calculate or edit its saved values.")};items(plastic,key={it.product.id}){p->Card(Modifier.fillMaxWidth().clickable{onProduct(p.product.id)}){Row(Modifier.padding(10.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(10.dp)){ProductImage(p.product.imageRef,Modifier.size(62.dp));Column(Modifier.weight(1f)){Text(p.product.name,fontWeight=FontWeight.Bold);Text("${p.material?.name?:"Material not set"} • ${p.product.materialWeightG?.let{"${trimNum(it)} g"}?:"Weight not set"}",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant);Text("Labour ₹${p.product.labourCost?.let(::trimNum)?:"0"} • Cost ₹${"%.2f".format(p.totalCost)}/pc",style=MaterialTheme.typography.bodySmall)};Text("›",style=MaterialTheme.typography.headlineSmall)}}};if(plastic.isEmpty())item{EmptyState("No plastic products match your search.")}}}}
}

@Composable
fun ReportsScreen(vm:FactoryViewModel,onBack:()->Unit){
    val context=LocalContext.current;val history by vm.outwardHistory.collectAsStateWithLifecycle();val locations by vm.locations.collectAsStateWithLifecycle();var period by remember{mutableStateOf("Month")};var locId by remember{mutableStateOf<String?>(null)};var query by remember{mutableStateOf("")};val today=LocalDate.now()
    val filtered=history.filter{s->val d=runCatching{LocalDate.parse(s.outward.date)}.getOrNull();val p=when(period){"Today"->d==today;"Week"->d!=null&&!d.isBefore(today.minusDays(6));"Month"->d!=null&&d.year==today.year&&d.month==today.month;else->true};val l=locId==null||s.outward.locationId==locId;val q=query.isBlank()||s.lines.any{it.productNameSnapshot.contains(query,true)};p&&l&&q}
    val allLines=filtered.flatMap{it.lines};val qty=allLines.sumOf{it.quantity};val bags=allLines.sumOf{it.bags};val productTotals=allLines.groupBy{it.productNameSnapshot}.mapValues{e->e.value.sumOf{it.quantity}}.toList().sortedByDescending{it.second}
    val reportText=buildString{appendLine("R D TECHNO - OUTWARD REPORT");appendLine("Period: $period");appendLine("Location: ${locations.firstOrNull{it.id==locId}?.name?:"All"}");appendLine("Outwards: ${filtered.size}");appendLine("Quantity: $qty");appendLine("Bags: $bags");appendLine();productTotals.forEach{appendLine("${it.first}: ${it.second}")}}
    Scaffold(topBar={SimpleTopBar("Reports",onBack,actions={IconButton(onClick={shareText(context,reportText)}){Icon(Icons.Default.Share,"Share")}})}){pad->LazyColumn(Modifier.fillMaxSize().padding(pad),contentPadding=PaddingValues(12.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        item{ScreenTitle("Outward Summary","Filter, review totals and share a text report.")}
        item{Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){listOf("Today","Week","Month","All").forEach{p->FilterChip(period==p,{period=p},{Text(p)})}}}
        item{Text("Location",fontWeight=FontWeight.SemiBold);FlowRow(horizontalArrangement=Arrangement.spacedBy(6.dp)){FilterChip(locId==null,{locId=null},{Text("All")});locations.filter{it.active}.forEach{l->FilterChip(locId==l.id,{locId=l.id},{Text(l.name)})}}}
        item{OutlinedTextField(query,{query=it},Modifier.fillMaxWidth(),label={Text("Product filter")},leadingIcon={Icon(Icons.Default.Search,null)},singleLine=true)}
        item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){Metric("Outwards",filtered.size.toString(),Modifier.weight(1f));Metric("Quantity",qty.toString(),Modifier.weight(1f));Metric("Bags",bags.toString(),Modifier.weight(1f))}}
        item{Text("Item-wise outward",style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold)}
        items(productTotals){(name,total)->Card(Modifier.fillMaxWidth()){Row(Modifier.padding(12.dp)){Text(name,Modifier.weight(1f));Text(total.toString(),fontWeight=FontWeight.Bold)}}}
    }}
}
