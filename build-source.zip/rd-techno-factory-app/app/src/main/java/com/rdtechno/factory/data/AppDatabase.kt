package com.rdtechno.factory.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        ProductCategoryEntity::class,
        MaterialEntity::class,
        ProductEntity::class,
        LocationEntity::class,
        OutwardEntity::class,
        OutwardLineEntity::class,
        OrderEntity::class,
        OrderLineEntity::class,
        OrderRequirementEntity::class,
        SettingEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun categoryDao(): CategoryDao
    abstract fun materialDao(): MaterialDao
    abstract fun productDao(): ProductDao
    abstract fun locationDao(): LocationDao
    abstract fun outwardDao(): OutwardDao
    abstract fun orderDao(): OrderDao
    abstract fun settingsDao(): SettingsDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun get(context: Context): AppDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "rd_techno_factory.db"
            ).build().also { INSTANCE = it }
        }
    }
}
