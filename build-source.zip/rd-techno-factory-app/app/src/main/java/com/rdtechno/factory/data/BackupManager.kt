package com.rdtechno.factory.data

import android.content.Context
import android.util.Base64
import androidx.room.withTransaction
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object BackupManager {
    suspend fun createBackup(context: Context, db: AppDatabase): String {
        val root = JSONObject()
        root.put("format", "rd-techno-backup")
        root.put("version", 1)
        root.put("createdAtMs", System.currentTimeMillis())
        root.put("categories", JSONArray().apply { db.categoryDao().getAllOnce().forEach { put(JSONObject().apply { put("id", it.id); put("name", it.name); put("active", it.active) }) } })
        root.put("materials", JSONArray().apply { db.materialDao().getAllOnce().forEach { put(JSONObject().apply { put("id", it.id); put("name", it.name); put("rate", it.ratePerKg); put("active", it.active); put("updated", it.updatedAtMs) }) } })
        root.put("products", JSONArray().apply { db.productDao().getAllOnce().forEach { p ->
            put(JSONObject().apply {
                put("id", p.id); put("name", p.name); put("categoryId", p.categoryId); putOrNull("imageRef", p.imageRef)
                put("active", p.active); putOrNull("materialId", p.materialId); putOrNull("weight", p.materialWeightG); putOrNull("labour", p.labourCost)
                put("notes", p.notes); putOrNull("driveId", p.legacyDriveFileId); put("created", p.createdAtMs); put("updated", p.updatedAtMs)
                putOrNull("netFinished", p.netFinishedWeightG); putOrNull("runner", p.runnerSprueWeightG); putOrNull("shot", p.totalShotWeightG)
                putOrNull("regrind", p.regrindPercentage); putOrNull("wastage", p.wastagePercentage)
            })
        } })
        root.put("locations", JSONArray().apply { db.locationDao().getAllOnce().forEach { l -> put(JSONObject().apply {
            put("id", l.id); put("name", l.name); put("company", l.companyName); put("address", l.address); put("contact", l.contactName)
            put("phone", l.phone); put("notes", l.notes); put("active", l.active); put("updated", l.updatedAtMs)
        }) } })
        root.put("outwards", JSONArray().apply { db.outwardDao().getOutwardsOnce().forEach { o -> put(JSONObject().apply {
            put("id", o.id); put("date", o.date); putOrNull("locationId", o.locationId); put("vehicle", o.vehicleNumber); put("notes", o.notes); put("created", o.createdAtMs); put("updated", o.updatedAtMs)
        }) } })
        root.put("outwardLines", JSONArray().apply { db.outwardDao().getLinesOnce().forEach { l -> put(JSONObject().apply {
            put("id", l.id); put("outwardId", l.outwardId); putOrNull("productId", l.productId); put("productName", l.productNameSnapshot); put("quantity", l.quantity); put("bags", l.bags)
        }) } })
        root.put("orders", JSONArray().apply { db.orderDao().getOrdersOnce().forEach { o -> put(JSONObject().apply {
            put("id", o.id); put("date", o.date); put("notes", o.notes); put("created", o.createdAtMs); put("updated", o.updatedAtMs)
        }) } })
        root.put("orderLines", JSONArray().apply { db.orderDao().getLinesOnce().forEach { l -> put(JSONObject().apply {
            put("id", l.id); put("orderId", l.orderId); putOrNull("productId", l.productId); put("productName", l.productNameSnapshot); put("material", l.materialSnapshot); put("priority", l.priority)
        }) } })
        root.put("orderRequirements", JSONArray().apply { db.orderDao().getRequirementsOnce().forEach { r -> put(JSONObject().apply {
            put("id", r.id); put("orderLineId", r.orderLineId); put("locationId", r.locationId); put("quantity", r.quantity)
        }) } })
        root.put("settings", JSONArray().apply { db.settingsDao().getAllOnce().forEach { s -> put(JSONObject().apply { put("key", s.key); put("value", s.value) }) } })

        val images = JSONObject()
        db.productDao().getAllOnce().forEach { p ->
            val ref = p.imageRef
            if (!ref.isNullOrBlank() && !ref.startsWith("res:")) {
                val f = File(ref)
                if (f.exists()) images.put(p.id, JSONObject().apply {
                    put("name", f.name)
                    put("base64", Base64.encodeToString(f.readBytes(), Base64.NO_WRAP))
                })
            }
        }
        root.put("customImages", images)
        return root.toString(2)
    }

    suspend fun restoreBackup(context: Context, db: AppDatabase, text: String) {
        val root = JSONObject(text)
        require(root.optString("format") == "rd-techno-backup") { "Not an R D Techno backup file" }
        val restoredImageRefs = mutableMapOf<String, String>()
        val images = root.optJSONObject("customImages") ?: JSONObject()
        images.keys().forEach { productId ->
            val obj = images.getJSONObject(productId)
            val safeName = obj.optString("name", "restored.jpg").replace(Regex("[^A-Za-z0-9._-]"), "_")
            val dir = File(context.filesDir, "product_images").apply { mkdirs() }
            val file = File(dir, "restore_${System.currentTimeMillis()}_${productId}_$safeName")
            file.writeBytes(Base64.decode(obj.getString("base64"), Base64.DEFAULT))
            restoredImageRefs[productId] = file.absolutePath
        }

        db.withTransaction {
            db.orderDao().clearRequirements(); db.orderDao().clearLines(); db.orderDao().clearOrders()
            db.outwardDao().clearLines(); db.outwardDao().clearOutwards()
            db.productDao().clear(); db.materialDao().clear(); db.locationDao().clear(); db.categoryDao().clear(); db.settingsDao().clear()

            db.categoryDao().insertAll(root.getJSONArray("categories").mapObjects { o -> ProductCategoryEntity(o.getString("id"), o.getString("name"), o.optBoolean("active", true)) })
            db.materialDao().insertAll(root.getJSONArray("materials").mapObjects { o -> MaterialEntity(o.getString("id"), o.getString("name"), o.getDouble("rate"), o.optBoolean("active", true), o.optLong("updated")) })
            db.productDao().insertAll(root.getJSONArray("products").mapObjects { o ->
                val id=o.getString("id")
                ProductEntity(
                    id=id, name=o.getString("name"), categoryId=o.getString("categoryId"),
                    imageRef=restoredImageRefs[id] ?: o.nullableString("imageRef"), active=o.optBoolean("active",true),
                    materialId=o.nullableString("materialId"), materialWeightG=o.nullableDouble("weight"), labourCost=o.nullableDouble("labour"),
                    notes=o.optString("notes",""), legacyDriveFileId=o.nullableString("driveId"), createdAtMs=o.optLong("created"), updatedAtMs=o.optLong("updated"),
                    netFinishedWeightG=o.nullableDouble("netFinished"), runnerSprueWeightG=o.nullableDouble("runner"), totalShotWeightG=o.nullableDouble("shot"),
                    regrindPercentage=o.nullableDouble("regrind"), wastagePercentage=o.nullableDouble("wastage")
                )
            })
            db.locationDao().insertAll(root.getJSONArray("locations").mapObjects { o -> LocationEntity(
                o.getString("id"),o.getString("name"),o.optString("company",""),o.optString("address",""),o.optString("contact",""),o.optString("phone",""),o.optString("notes",""),o.optBoolean("active",true),o.optLong("updated")
            ) })
            db.outwardDao().insertOutwards(root.getJSONArray("outwards").mapObjects { o -> OutwardEntity(o.getString("id"),o.getString("date"),o.nullableString("locationId"),o.optString("vehicle",""),o.optString("notes",""),o.optLong("created"),o.optLong("updated")) })
            db.outwardDao().insertLines(root.getJSONArray("outwardLines").mapObjects { o -> OutwardLineEntity(o.getString("id"),o.getString("outwardId"),o.nullableString("productId"),o.getString("productName"),o.getInt("quantity"),o.optInt("bags",0)) })
            db.orderDao().insertOrders(root.getJSONArray("orders").mapObjects { o -> OrderEntity(o.getString("id"),o.getString("date"),o.optString("notes",""),o.optLong("created"),o.optLong("updated")) })
            db.orderDao().insertLines(root.getJSONArray("orderLines").mapObjects { o -> OrderLineEntity(o.getString("id"),o.getString("orderId"),o.nullableString("productId"),o.getString("productName"),o.optString("material",""),o.optInt("priority",999)) })
            db.orderDao().insertRequirements(root.getJSONArray("orderRequirements").mapObjects { o -> OrderRequirementEntity(o.getString("id"),o.getString("orderLineId"),o.getString("locationId"),o.getInt("quantity")) })
            db.settingsDao().insertAll(root.optJSONArray("settings")?.mapObjects { o -> SettingEntity(o.getString("key"),o.getString("value")) } ?: emptyList())
        }
    }

    suspend fun productsCsv(db: AppDatabase): String {
        val materials = db.materialDao().getAllOnce().associateBy { it.id }
        val categories = db.categoryDao().getAllOnce().associateBy { it.id }
        return buildString {
            appendLine("ID,Name,Category,Material,Weight g,Material rate,Labour,Cost per piece,Active")
            db.productDao().getAllOnce().forEach { p ->
                val m=materials[p.materialId]; val matCost=((p.materialWeightG ?: 0.0)/1000.0)*(m?.ratePerKg ?: 0.0); val total=matCost+(p.labourCost ?: 0.0)
                appendLine(listOf(p.id,p.name,categories[p.categoryId]?.name.orEmpty(),m?.name.orEmpty(),p.materialWeightG?.toString().orEmpty(),m?.ratePerKg?.toString().orEmpty(),p.labourCost?.toString().orEmpty(),"%.2f".format(total),p.active.toString()).joinToString(",") { csv(it) })
            }
        }
    }

    suspend fun outwardsCsv(db: AppDatabase): String {
        val locations=db.locationDao().getAllOnce().associateBy { it.id }; val lines=db.outwardDao().getLinesOnce().groupBy { it.outwardId }
        return buildString {
            appendLine("Date,Location,Vehicle,Product,Quantity,Bags")
            db.outwardDao().getOutwardsOnce().forEach { o ->
                (lines[o.id] ?: emptyList()).forEach { l -> appendLine(listOf(o.date,locations[o.locationId]?.name.orEmpty(),o.vehicleNumber,l.productNameSnapshot,l.quantity.toString(),l.bags.toString()).joinToString(",") { csv(it) }) }
            }
        }
    }

    private fun JSONObject.putOrNull(key:String,value:Any?) { put(key, value ?: JSONObject.NULL) }
    private fun csv(s:String)= if(s.contains(',')||s.contains('"')||s.contains('\n')) "\"${s.replace("\"","\"\"")}\"" else s
    private fun JSONObject.nullableString(key:String):String?=if(!has(key)||isNull(key)) null else optString(key).takeIf{it.isNotBlank()&&it!="null"}
    private fun JSONObject.nullableDouble(key:String):Double?=if(!has(key)||isNull(key)) null else optDouble(key).takeIf{!it.isNaN()}
    private inline fun <T> JSONArray.mapObjects(block:(JSONObject)->T):List<T>=(0 until length()).map{block(getJSONObject(it))}
}
