package com.rdtechno.factory.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "product_categories", indices = [Index(value = ["name"], unique = true)])
data class ProductCategoryEntity(
    @PrimaryKey val id: String,
    val name: String,
    val active: Boolean = true
)

@Entity(tableName = "materials", indices = [Index(value = ["name"], unique = true)])
data class MaterialEntity(
    @PrimaryKey val id: String,
    val name: String,
    val ratePerKg: Double,
    val active: Boolean = true,
    val updatedAtMs: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "products",
    indices = [Index("categoryId"), Index("materialId"), Index("name")]
)
data class ProductEntity(
    @PrimaryKey val id: String,
    val name: String,
    val categoryId: String,
    val imageRef: String? = null,
    val active: Boolean = true,
    val materialId: String? = null,
    val materialWeightG: Double? = null,
    val labourCost: Double? = null,
    val notes: String = "",
    val legacyDriveFileId: String? = null,
    val createdAtMs: Long = System.currentTimeMillis(),
    val updatedAtMs: Long = System.currentTimeMillis(),
    val netFinishedWeightG: Double? = null,
    val runnerSprueWeightG: Double? = null,
    val totalShotWeightG: Double? = null,
    val regrindPercentage: Double? = null,
    val wastagePercentage: Double? = null
)

@Entity(tableName = "locations", indices = [Index(value = ["name"], unique = true)])
data class LocationEntity(
    @PrimaryKey val id: String,
    val name: String,
    val companyName: String = "",
    val address: String = "",
    val contactName: String = "",
    val phone: String = "",
    val notes: String = "",
    val active: Boolean = true,
    val updatedAtMs: Long = System.currentTimeMillis()
)

@Entity(tableName = "outwards", indices = [Index("date"), Index("locationId")])
data class OutwardEntity(
    @PrimaryKey val id: String,
    val date: String,
    val locationId: String? = null,
    val vehicleNumber: String = "",
    val notes: String = "",
    val createdAtMs: Long = System.currentTimeMillis(),
    val updatedAtMs: Long = System.currentTimeMillis()
)

@Entity(tableName = "outward_lines", indices = [Index("outwardId"), Index("productId")])
data class OutwardLineEntity(
    @PrimaryKey val id: String,
    val outwardId: String,
    val productId: String? = null,
    val productNameSnapshot: String,
    val quantity: Int,
    val bags: Int = 0
)

@Entity(tableName = "orders", indices = [Index("date")])
data class OrderEntity(
    @PrimaryKey val id: String,
    val date: String,
    val notes: String = "",
    val createdAtMs: Long = System.currentTimeMillis(),
    val updatedAtMs: Long = System.currentTimeMillis()
)

@Entity(tableName = "order_lines", indices = [Index("orderId"), Index("productId")])
data class OrderLineEntity(
    @PrimaryKey val id: String,
    val orderId: String,
    val productId: String? = null,
    val productNameSnapshot: String,
    val materialSnapshot: String = "",
    val priority: Int = 999
)

@Entity(tableName = "order_requirements", indices = [Index("orderLineId"), Index("locationId")])
data class OrderRequirementEntity(
    @PrimaryKey val id: String,
    val orderLineId: String,
    val locationId: String,
    val quantity: Int
)

@Entity(tableName = "app_settings")
data class SettingEntity(
    @PrimaryKey val key: String,
    val value: String
)
