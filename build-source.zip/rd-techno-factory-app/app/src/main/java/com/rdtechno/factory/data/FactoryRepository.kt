package com.rdtechno.factory.data

import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate
import java.util.UUID

class FactoryRepository(private val db: AppDatabase) {
    val categories: Flow<List<ProductCategoryEntity>> = db.categoryDao().observeAll()
    val materials: Flow<List<MaterialEntity>> = db.materialDao().observeAll()
    val products: Flow<List<ProductEntity>> = db.productDao().observeAll()
    val locations: Flow<List<LocationEntity>> = db.locationDao().observeAll()
    val outwards: Flow<List<OutwardEntity>> = db.outwardDao().observeOutwards()
    val outwardLines: Flow<List<OutwardLineEntity>> = db.outwardDao().observeLines()
    val orders: Flow<List<OrderEntity>> = db.orderDao().observeOrders()
    val orderLines: Flow<List<OrderLineEntity>> = db.orderDao().observeLines()
    val orderRequirements: Flow<List<OrderRequirementEntity>> = db.orderDao().observeRequirements()

    suspend fun saveProduct(product: ProductEntity) = db.productDao().upsert(product.copy(updatedAtMs = System.currentTimeMillis()))
    suspend fun deleteProduct(id: String) = db.productDao().deleteById(id)
    suspend fun product(id: String) = db.productDao().getById(id)

    suspend fun saveMaterial(material: MaterialEntity) = db.materialDao().upsert(material.copy(updatedAtMs = System.currentTimeMillis()))
    suspend fun deleteMaterial(id: String) = db.materialDao().deleteById(id)
    suspend fun saveCategory(category: ProductCategoryEntity) = db.categoryDao().upsert(category)

    suspend fun saveLocation(location: LocationEntity) = db.locationDao().upsert(location.copy(updatedAtMs = System.currentTimeMillis()))
    suspend fun deleteLocation(id: String) = db.locationDao().deleteById(id)

    suspend fun saveOutward(
        existingId: String? = null,
        date: String = LocalDate.now().toString(),
        locationId: String?,
        vehicle: String,
        notes: String,
        cart: List<CartLineInput>
    ): String {
        val now = System.currentTimeMillis()
        val id = existingId ?: "OUT-${now}-${UUID.randomUUID().toString().take(6)}"
        db.withTransaction {
            db.outwardDao().upsertOutward(OutwardEntity(id, date, locationId, vehicle.trim(), notes.trim(), now, now))
            db.outwardDao().deleteLinesForOutward(id)
            cart.filter { it.quantity > 0 }.forEach { line ->
                db.outwardDao().upsertLine(
                    OutwardLineEntity(
                        id = "${id}_${line.productId}", outwardId = id, productId = line.productId,
                        productNameSnapshot = line.productName, quantity = line.quantity, bags = line.bags.coerceAtLeast(0)
                    )
                )
            }
        }
        return id
    }

    suspend fun deleteOutward(id: String) = db.withTransaction {
        db.outwardDao().deleteLinesForOutward(id)
        db.outwardDao().deleteOutward(id)
    }

    suspend fun saveOrder(
        date: String = LocalDate.now().toString(),
        notes: String,
        lines: List<OrderLineInput>
    ): String {
        val now = System.currentTimeMillis()
        val id = "ORD-${now}-${UUID.randomUUID().toString().take(6)}"
        db.withTransaction {
            db.orderDao().upsertOrder(OrderEntity(id, date, notes.trim(), now, now))
            lines.sortedBy { it.priority }.forEach { input ->
                val lineId = "${id}_${input.productId}"
                db.orderDao().upsertLine(
                    OrderLineEntity(lineId, id, input.productId, input.productName, input.materialName, input.priority)
                )
                input.requirements.filterValues { it > 0 }.forEach { (locationId, qty) ->
                    db.orderDao().upsertRequirement(OrderRequirementEntity("${lineId}_${locationId}", lineId, locationId, qty))
                }
            }
        }
        return id
    }

    suspend fun deleteOrder(id: String) = db.withTransaction {
        db.orderDao().deleteRequirementsForOrder(id)
        db.orderDao().deleteLinesForOrder(id)
        db.orderDao().deleteOrder(id)
    }
}

data class CartLineInput(
    val productId: String,
    val productName: String,
    val quantity: Int,
    val bags: Int
)

data class OrderLineInput(
    val productId: String,
    val productName: String,
    val materialName: String,
    val priority: Int,
    val requirements: Map<String, Int>
)
