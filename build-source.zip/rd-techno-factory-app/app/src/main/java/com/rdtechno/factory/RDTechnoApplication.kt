package com.rdtechno.factory

import android.app.Application
import com.rdtechno.factory.data.AppDatabase
import com.rdtechno.factory.data.FactoryRepository

class RDTechnoApplication : Application() {
    val database by lazy { AppDatabase.get(this) }
    val repository by lazy { FactoryRepository(database) }
}
