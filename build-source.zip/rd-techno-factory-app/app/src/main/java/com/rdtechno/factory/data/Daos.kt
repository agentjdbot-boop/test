package com.rdtechno.factory.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface CategoryDao {
    @Query("SELECT * FROM product_categories ORDER BY name") fun observeAll(): Flow<List<ProductCategoryEntity>>
    @Query("SELECT * FROM product_categories ORDER BY name") suspend fun getAllOnce(): List<ProductCategoryEntity>
    @Query("SELECT COUNT(*) FROM product_categories") suspend fun count(): Int
    @Upsert suspend fun upsert(item: ProductCategoryEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(items: List<ProductCategoryEntity>)
    @Query("DELETE FROM product_categories") suspend fun clear()
}

@Dao
interface MaterialDao {
    @Query("SELECT * FROM materials ORDER BY name") fun observeAll(): Flow<List<MaterialEntity>>
    @Query("SELECT * FROM materials ORDER BY name") suspend fun getAllOnce(): List<MaterialEntity>
    @Query("SELECT * FROM materials WHERE id=:id LIMIT 1") suspend fun getById(id: String): MaterialEntity?
    @Upsert suspend fun upsert(item: MaterialEntity)
    @Query("DELETE FROM materials WHERE id=:id") suspend fun deleteById(id: String)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(items: List<MaterialEntity>)
    @Query("DELETE FROM materials") suspend fun clear()
}

@Dao
interface ProductDao {
    @Query("SELECT * FROM products ORDER BY name") fun observeAll(): Flow<List<ProductEntity>>
    @Query("SELECT * FROM products ORDER BY name") suspend fun getAllOnce(): List<ProductEntity>
    @Query("SELECT * FROM products WHERE id=:id LIMIT 1") suspend fun getById(id: String): ProductEntity?
    @Query("SELECT COUNT(*) FROM products") suspend fun count(): Int
    @Upsert suspend fun upsert(item: ProductEntity)
    @Query("DELETE FROM products WHERE id=:id") suspend fun deleteById(id: String)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(items: List<ProductEntity>)
    @Query("DELETE FROM products") suspend fun clear()
}

@Dao
interface LocationDao {
    @Query("SELECT * FROM locations ORDER BY name") fun observeAll(): Flow<List<LocationEntity>>
    @Query("SELECT * FROM locations ORDER BY name") suspend fun getAllOnce(): List<LocationEntity>
    @Query("SELECT * FROM locations WHERE id=:id LIMIT 1") suspend fun getById(id: String): LocationEntity?
    @Upsert suspend fun upsert(item: LocationEntity)
    @Query("DELETE FROM locations WHERE id=:id") suspend fun deleteById(id: String)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(items: List<LocationEntity>)
    @Query("DELETE FROM locations") suspend fun clear()
}

@Dao
interface OutwardDao {
    @Query("SELECT * FROM outwards ORDER BY date DESC, createdAtMs DESC") fun observeOutwards(): Flow<List<OutwardEntity>>
    @Query("SELECT * FROM outward_lines") fun observeLines(): Flow<List<OutwardLineEntity>>
    @Query("SELECT * FROM outwards ORDER BY date DESC, createdAtMs DESC") suspend fun getOutwardsOnce(): List<OutwardEntity>
    @Query("SELECT * FROM outward_lines") suspend fun getLinesOnce(): List<OutwardLineEntity>
    @Query("SELECT * FROM outward_lines WHERE outwardId=:outwardId") suspend fun getLinesForOutward(outwardId: String): List<OutwardLineEntity>
    @Upsert suspend fun upsertOutward(item: OutwardEntity)
    @Upsert suspend fun upsertLine(item: OutwardLineEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertOutwards(items: List<OutwardEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertLines(items: List<OutwardLineEntity>)
    @Query("DELETE FROM outward_lines WHERE outwardId=:outwardId") suspend fun deleteLinesForOutward(outwardId: String)
    @Query("DELETE FROM outwards WHERE id=:id") suspend fun deleteOutward(id: String)
    @Query("DELETE FROM outward_lines") suspend fun clearLines()
    @Query("DELETE FROM outwards") suspend fun clearOutwards()
}

@Dao
interface OrderDao {
    @Query("SELECT * FROM orders ORDER BY date DESC, createdAtMs DESC") fun observeOrders(): Flow<List<OrderEntity>>
    @Query("SELECT * FROM order_lines") fun observeLines(): Flow<List<OrderLineEntity>>
    @Query("SELECT * FROM order_requirements") fun observeRequirements(): Flow<List<OrderRequirementEntity>>
    @Query("SELECT * FROM orders ORDER BY date DESC, createdAtMs DESC") suspend fun getOrdersOnce(): List<OrderEntity>
    @Query("SELECT * FROM order_lines") suspend fun getLinesOnce(): List<OrderLineEntity>
    @Query("SELECT * FROM order_requirements") suspend fun getRequirementsOnce(): List<OrderRequirementEntity>
    @Upsert suspend fun upsertOrder(item: OrderEntity)
    @Upsert suspend fun upsertLine(item: OrderLineEntity)
    @Upsert suspend fun upsertRequirement(item: OrderRequirementEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertOrders(items: List<OrderEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertLines(items: List<OrderLineEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertRequirements(items: List<OrderRequirementEntity>)
    @Query("DELETE FROM order_requirements WHERE orderLineId IN (SELECT id FROM order_lines WHERE orderId=:orderId)") suspend fun deleteRequirementsForOrder(orderId: String)
    @Query("DELETE FROM order_lines WHERE orderId=:orderId") suspend fun deleteLinesForOrder(orderId: String)
    @Query("DELETE FROM orders WHERE id=:id") suspend fun deleteOrder(id: String)
    @Query("DELETE FROM order_requirements") suspend fun clearRequirements()
    @Query("DELETE FROM order_lines") suspend fun clearLines()
    @Query("DELETE FROM orders") suspend fun clearOrders()
}

@Dao
interface SettingsDao {
    @Query("SELECT * FROM app_settings") suspend fun getAllOnce(): List<SettingEntity>
    @Query("SELECT value FROM app_settings WHERE `key`=:key LIMIT 1") suspend fun get(key: String): String?
    @Upsert suspend fun upsert(item: SettingEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(items: List<SettingEntity>)
    @Query("DELETE FROM app_settings") suspend fun clear()
}
