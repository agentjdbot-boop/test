package com.rdtechno.factory.ui

import android.content.Intent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.rdtechno.factory.viewmodel.FactoryViewModel
import com.rdtechno.factory.viewmodel.ProductUi
import java.time.LocalDate

@Composable
fun OutwardSelectScreen(vm: FactoryViewModel, onBack: () -> Unit, onContinue: () -> Unit, onHistory: () -> Unit, onOrders: () -> Unit, onReports: () -> Unit, onManageLocations: () -> Unit) {
    val locations by vm.locations.collectAsStateWithLifecycle()
    Scaffold(topBar = { SimpleTopBar("Outward", onBack, actions = { IconButton(onClick=onManageLocations){Icon(Icons.Default.LocationOn,"Locations")} }) }) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad), contentPadding=PaddingValues(14.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
            item { ScreenTitle("Where is this outward going?", "Select a saved location to start.") }
            item { Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick=onHistory, modifier=Modifier.weight(1f)){Icon(Icons.Default.History,null);Spacer(Modifier.width(4.dp));Text("History")}
                OutlinedButton(onClick=onOrders, modifier=Modifier.weight(1f)){Icon(Icons.Default.Assignment,null);Spacer(Modifier.width(4.dp));Text("Orders")}
                OutlinedButton(onClick=onReports, modifier=Modifier.weight(1f)){Icon(Icons.Default.Summarize,null);Spacer(Modifier.width(4.dp));Text("Reports")}
            } }
            items(locations.filter{it.active}, key={it.id}) { l ->
                Card(Modifier.fillMaxWidth().clickable { vm.startOutward(l.id); onContinue() }) {
                    Row(Modifier.padding(18.dp), verticalAlignment=Alignment.CenterVertically) {
                        Icon(Icons.Default.LocationOn,null,tint=MaterialTheme.colorScheme.secondary);Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)){Text(l.name,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold);if(l.companyName.isNotBlank())Text(l.companyName,style=MaterialTheme.typography.bodySmall)}
                        Text("›",style=MaterialTheme.typography.headlineSmall)
                    }
                }
            }
            item { OutlinedButton(onClick=onManageLocations,Modifier.fillMaxWidth()){Icon(Icons.Default.Add,null);Spacer(Modifier.width(6.dp));Text("Add / Manage Locations")} }
        }
    }
}

@Composable
fun OutwardDetailsScreen(vm: FactoryViewModel, onBack:()->Unit, onProducts:()->Unit) {
    val draft by vm.outwardDraft.collectAsStateWithLifecycle(); val locations by vm.locations.collectAsStateWithLifecycle(); val loc=locations.firstOrNull{it.id==draft.selectedLocationId}
    Scaffold(topBar={SimpleTopBar("Outward Details",onBack)}){pad->LazyColumn(Modifier.fillMaxSize().padding(pad),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        item { Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text(loc?.name ?: "No location",fontWeight=FontWeight.Bold,style=MaterialTheme.typography.titleLarge); if(!loc?.companyName.isNullOrBlank())Text(loc!!.companyName); if(!loc?.address.isNullOrBlank())Text(loc!!.address,style=MaterialTheme.typography.bodySmall)}} }
        item { OutlinedTextField(draft.date,{vm.setOutwardDate(it)},Modifier.fillMaxWidth(),label={Text("Date (YYYY-MM-DD)")},singleLine=true) }
        item { OutlinedTextField(draft.vehicle,{vm.setOutwardVehicle(it.uppercase())},Modifier.fillMaxWidth(),label={Text("Vehicle Number")},singleLine=true) }
        item { OutlinedTextField(draft.notes,{vm.setOutwardNotes(it)},Modifier.fillMaxWidth(),label={Text("Notes (optional)")},minLines=2) }
        item { Button(onClick=onProducts,Modifier.fillMaxWidth().height(54.dp)){Icon(Icons.Default.AddShoppingCart,null);Spacer(Modifier.width(8.dp));Text(if(draft.cart.isEmpty())"ADD PRODUCTS" else "CONTINUE TO PRODUCTS (${draft.cart.size})")} }
    }}
}

@Composable
fun OutwardProductBrowserScreen(vm:FactoryViewModel,onBack:()->Unit,onCart:()->Unit){
    val products by vm.products.collectAsStateWithLifecycle();val draft by vm.outwardDraft.collectAsStateWithLifecycle();val categories by vm.categories.collectAsStateWithLifecycle();var query by remember{mutableStateOf("")};var cat by remember{mutableStateOf<String?>(null)}
    val filtered=products.filter{it.product.active&&(cat==null||it.product.categoryId==cat)&&(query.isBlank()||it.product.name.contains(query,true))}
    Scaffold(topBar={SimpleTopBar("Add Products",onBack)},bottomBar={Surface(shadowElevation=6.dp){Button(onClick=onCart,enabled=draft.cart.isNotEmpty(),modifier=Modifier.fillMaxWidth().padding(12.dp).height(50.dp)){Text("VIEW OUTWARD CART (${draft.cart.size})")}}}){pad->Column(Modifier.fillMaxSize().padding(pad)){
        OutlinedTextField(query,{query=it},Modifier.fillMaxWidth().padding(12.dp),label={Text("Search product")},leadingIcon={Icon(Icons.Default.Search,null)},singleLine=true)
        Row(Modifier.padding(horizontal=12.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){FilterChip(cat==null,{cat=null},{Text("All")});categories.filter{it.active}.forEach{c->FilterChip(cat==c.id,{cat=c.id},{Text(c.name.removeSuffix(" Products"))})}}
        LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){items(filtered,key={it.product.id}){p->ProductListRow(p,onClick={vm.addToOutward(p)},trailing={if(draft.cart.containsKey(p.product.id))AssistChip({}, {Text("Added")}, enabled=false)else Button(onClick={vm.addToOutward(p)}){Text("ADD")}})}}
    }}
}

@Composable
fun OutwardCartScreen(vm:FactoryViewModel,onBack:()->Unit,onContinue:()->Unit){
    val draft by vm.outwardDraft.collectAsStateWithLifecycle();val products by vm.products.collectAsStateWithLifecycle();val productMap=products.associateBy{it.product.id};val totalQty=draft.cart.values.sumOf{it.quantity};val totalBags=draft.cart.values.sumOf{it.bags}
    Scaffold(topBar={SimpleTopBar("Outward Cart",onBack)},bottomBar={Surface(shadowElevation=6.dp){Button(onClick=onContinue, enabled=draft.cart.values.any{it.quantity>0}, modifier=Modifier.fillMaxWidth().padding(12.dp).height(50.dp)){Text("CONTINUE")}}}){pad->LazyColumn(Modifier.fillMaxSize().padding(pad),contentPadding=PaddingValues(12.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        items(draft.cart.values.toList(),key={it.productId}){line->val p=productMap[line.productId];Card(Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
            Row(verticalAlignment=Alignment.CenterVertically){ProductImage(p?.product?.imageRef,Modifier.size(56.dp));Spacer(Modifier.width(10.dp));Text(line.productName,Modifier.weight(1f),fontWeight=FontWeight.Bold);IconButton(onClick={vm.removeOutwardItem(line.productId)}){Icon(Icons.Default.Delete,null)}}
            Text("Quantity",style=MaterialTheme.typography.labelMedium)
            Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(6.dp)){IconButton(onClick={vm.changeOutwardQuantity(line.productId,line.quantity-1)}){Icon(Icons.Default.Remove,null)};OutlinedTextField(line.quantity.toString(),{vm.changeOutwardQuantity(line.productId,it.toIntOrNull()?:0)},Modifier.width(120.dp),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),singleLine=true);IconButton(onClick={vm.changeOutwardQuantity(line.productId,line.quantity+1)}){Icon(Icons.Default.Add,null)};TextButton(onClick={vm.changeOutwardQuantity(line.productId,line.quantity+100)}){Text("+100")};TextButton(onClick={vm.changeOutwardQuantity(line.productId,line.quantity+500)}){Text("+500")}}
            OutlinedTextField(line.bags.toString(),{vm.changeOutwardBags(line.productId,it.toIntOrNull()?:0)},Modifier.fillMaxWidth(),label={Text("Bags")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),singleLine=true)
        }}}
        item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){Metric("Products",draft.cart.size.toString(),Modifier.weight(1f));Metric("Quantity",totalQty.toString(),Modifier.weight(1f));Metric("Bags",totalBags.toString(),Modifier.weight(1f))};Spacer(Modifier.height(70.dp))}
    }}
}

@Composable
fun OutwardReviewScreen(vm:FactoryViewModel,onBack:()->Unit,onSaved:(String)->Unit){
    val draft by vm.outwardDraft.collectAsStateWithLifecycle();val locations by vm.locations.collectAsStateWithLifecycle();val loc=locations.firstOrNull{it.id==draft.selectedLocationId}
    Scaffold(topBar={SimpleTopBar("Review Outward",onBack)},bottomBar={Surface(shadowElevation=6.dp){Button(onClick={vm.saveOutward(onSaved)},Modifier.fillMaxWidth().padding(12.dp).height(52.dp)){Icon(Icons.Default.Save,null);Spacer(Modifier.width(6.dp));Text("SAVE OUTWARD")}}}){pad->LazyColumn(Modifier.fillMaxSize().padding(pad),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        item{ScreenTitle("OUTWARD REVIEW")}
        item{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){Text("Location: ${loc?.name ?: "—"}");Text("Vehicle: ${draft.vehicle.ifBlank{"—"}}");Text("Date: ${draft.date}")}}}
        items(draft.cart.values.filter{it.quantity>0}){l->Card(Modifier.fillMaxWidth()){Row(Modifier.padding(14.dp)){Column(Modifier.weight(1f)){Text(l.productName,fontWeight=FontWeight.Bold);Text("${l.quantity} pcs")};Text("${l.bags} bags")}}}
        item{HorizontalDivider();Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){Metric("Products",draft.cart.values.count{it.quantity>0}.toString(),Modifier.weight(1f));Metric("Quantity",draft.cart.values.sumOf{it.quantity}.toString(),Modifier.weight(1f));Metric("Bags",draft.cart.values.sumOf{it.bags}.toString(),Modifier.weight(1f))};Spacer(Modifier.height(70.dp))}
    }}
}

@Composable
fun OutwardHistoryScreen(vm:FactoryViewModel,onBack:()->Unit,onOpen:(String)->Unit){
    val history by vm.outwardHistory.collectAsStateWithLifecycle();var mode by remember{mutableStateOf("All")};var query by remember{mutableStateOf("")};val today=LocalDate.now();val filtered=history.filter{s->val date=runCatching{LocalDate.parse(s.outward.date)}.getOrNull();val timeOk=when(mode){"Today"->date==today;"Week"->date!=null&&!date.isBefore(today.minusDays(6));"Month"->date!=null&&date.month==today.month&&date.year==today.year;else->true};val searchOk=query.isBlank()||s.locationName.contains(query,true)||s.outward.vehicleNumber.contains(query,true)||s.lines.any{it.productNameSnapshot.contains(query,true)};timeOk&&searchOk}
    Scaffold(topBar={SimpleTopBar("Outward History",onBack)}){pad->Column(Modifier.fillMaxSize().padding(pad)){OutlinedTextField(query,{query=it},Modifier.fillMaxWidth().padding(12.dp),label={Text("Search location, vehicle or product")},leadingIcon={Icon(Icons.Default.Search,null)},singleLine=true);Row(Modifier.padding(horizontal=12.dp),horizontalArrangement=Arrangement.spacedBy(6.dp)){listOf("Today","Week","Month","All").forEach{m->FilterChip(mode==m,{mode=m},{Text(m)})}};LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){items(filtered,key={it.outward.id}){s->Card(Modifier.fillMaxWidth().clickable{onOpen(s.outward.id)}){Column(Modifier.padding(14.dp)){Row{Text(s.locationName,Modifier.weight(1f),fontWeight=FontWeight.Bold);Text(s.outward.date)};Text(s.outward.vehicleNumber.ifBlank{"Vehicle not saved"},style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant);Text("${s.lines.size} products • ${s.lines.sumOf{it.quantity}} pcs • ${s.lines.sumOf{it.bags}} bags",style=MaterialTheme.typography.bodySmall)}}};if(filtered.isEmpty())item{EmptyState("No outward records match this filter.")}}}}
}

@Composable
fun OutwardViewScreen(vm:FactoryViewModel,id:String,onBack:()->Unit){
    val context=LocalContext.current;val history by vm.outwardHistory.collectAsStateWithLifecycle();val s=history.firstOrNull{it.outward.id==id};var confirmDelete by remember{mutableStateOf(false)}
    Scaffold(topBar={SimpleTopBar("Outward",onBack,actions={if(s!=null){IconButton(onClick={shareText(context,outwardShareText(s.locationName,s.outward.date,s.outward.vehicleNumber,s.lines.map{Triple(it.productNameSnapshot,it.quantity,it.bags)}))}){Icon(Icons.Default.Share,"Share")};IconButton(onClick={confirmDelete=true}){Icon(Icons.Default.Delete,"Delete")}}})}){pad->if(s==null)EmptyState("Outward not found")else LazyColumn(Modifier.fillMaxSize().padding(pad),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){item{ScreenTitle(s.locationName,s.outward.date);Text("Vehicle: ${s.outward.vehicleNumber.ifBlank{"—"}}")};items(s.lines){l->Card(Modifier.fillMaxWidth()){Row(Modifier.padding(14.dp)){Text(l.productNameSnapshot,Modifier.weight(1f),fontWeight=FontWeight.SemiBold);Text("${l.quantity} pcs  •  ${l.bags} bags")}}};item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){Metric("Products",s.lines.size.toString(),Modifier.weight(1f));Metric("Quantity",s.lines.sumOf{it.quantity}.toString(),Modifier.weight(1f));Metric("Bags",s.lines.sumOf{it.bags}.toString(),Modifier.weight(1f))}}}}
    if(confirmDelete)AlertDialog(onDismissRequest={confirmDelete=false},title={Text("Delete this outward?")},text={Text("This cannot be undone unless you restore a backup.")},confirmButton={Button(onClick={confirmDelete=false;vm.deleteOutward(id);onBack()},colors=ButtonDefaults.buttonColors(containerColor=MaterialTheme.colorScheme.error)){Text("Delete")}},dismissButton={TextButton(onClick={confirmDelete=false}){Text("Cancel")}})
}

fun outwardShareText(location:String,date:String,vehicle:String,lines:List<Triple<String,Int,Int>>):String=buildString{appendLine("R D TECHNO - OUTWARD");appendLine("Date: $date");appendLine("Location: $location");appendLine("Vehicle: ${vehicle.ifBlank{"-"}}");appendLine();lines.forEach{appendLine("${it.first}: ${it.second} pcs, ${it.third} bags")};appendLine();appendLine("Total: ${lines.sumOf{it.second}} pcs, ${lines.sumOf{it.third}} bags")}
fun shareText(context:android.content.Context,text:String){context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_TEXT,text)},"Share"))}
