package com.rdtechno.factory.data

import android.content.Context
import androidx.room.withTransaction
import org.json.JSONArray
import org.json.JSONObject

object SeedImporter {
    suspend fun seedIfNeeded(context: Context, db: AppDatabase) {
        if (db.productDao().count() > 0) return
        val raw = context.assets.open("seed.json").bufferedReader().use { it.readText() }
        val root = JSONObject(raw)
        db.withTransaction {
            db.categoryDao().insertAll(root.getJSONArray("categories").mapObjects { o ->
                ProductCategoryEntity(o.getString("id"), o.getString("name"), o.optBoolean("active", true))
            })
            db.materialDao().insertAll(root.getJSONArray("materials").mapObjects { o ->
                MaterialEntity(o.getString("id"), o.getString("name"), o.getDouble("ratePerKg"), o.optBoolean("active", true))
            })
            db.productDao().insertAll(root.getJSONArray("products").mapObjects { o ->
                ProductEntity(
                    id = o.getString("id"),
                    name = o.getString("name"),
                    categoryId = o.getString("categoryId"),
                    imageRef = o.nullableString("imageRef"),
                    active = o.optBoolean("active", true),
                    materialId = o.nullableString("materialId"),
                    materialWeightG = o.nullableDouble("materialWeightG"),
                    labourCost = o.nullableDouble("labourCost"),
                    notes = o.optString("notes", ""),
                    legacyDriveFileId = o.nullableString("legacyDriveFileId")
                )
            })
            db.locationDao().insertAll(root.getJSONArray("locations").mapObjects { o ->
                LocationEntity(
                    id = o.getString("id"), name = o.getString("name"), companyName = o.optString("companyName", ""),
                    address = o.optString("address", ""), contactName = o.optString("contactName", ""),
                    phone = o.optString("phone", ""), notes = o.optString("notes", ""), active = o.optBoolean("active", true)
                )
            })
            db.outwardDao().insertOutwards(root.getJSONArray("outwards").mapObjects { o ->
                OutwardEntity(
                    id = o.getString("id"), date = o.getString("date"), locationId = o.nullableString("locationId"),
                    vehicleNumber = o.optString("vehicleNumber", ""), notes = o.optString("notes", ""),
                    createdAtMs = o.optLong("createdAtMs", System.currentTimeMillis()),
                    updatedAtMs = o.optLong("updatedAtMs", System.currentTimeMillis())
                )
            })
            db.outwardDao().insertLines(root.getJSONArray("outwardLines").mapObjects { o ->
                OutwardLineEntity(
                    id = o.getString("id"), outwardId = o.getString("outwardId"), productId = o.nullableString("productId"),
                    productNameSnapshot = o.getString("productNameSnapshot"), quantity = o.getInt("quantity"), bags = o.optInt("bags", 0)
                )
            })
            db.orderDao().insertOrders(root.getJSONArray("orders").mapObjects { o ->
                OrderEntity(
                    id = o.getString("id"), date = o.getString("date"), notes = o.optString("notes", ""),
                    createdAtMs = o.optLong("createdAtMs", System.currentTimeMillis()),
                    updatedAtMs = o.optLong("updatedAtMs", System.currentTimeMillis())
                )
            })
            db.orderDao().insertLines(root.getJSONArray("orderLines").mapObjects { o ->
                OrderLineEntity(
                    id = o.getString("id"), orderId = o.getString("orderId"), productId = o.nullableString("productId"),
                    productNameSnapshot = o.getString("productNameSnapshot"), materialSnapshot = o.optString("materialSnapshot", ""),
                    priority = o.optInt("priority", 999)
                )
            })
            db.orderDao().insertRequirements(root.getJSONArray("orderRequirements").mapObjects { o ->
                OrderRequirementEntity(
                    id = o.getString("id"), orderLineId = o.getString("orderLineId"), locationId = o.getString("locationId"),
                    quantity = o.getInt("quantity")
                )
            })
            db.settingsDao().upsert(SettingEntity("seed_version", root.optInt("schemaVersion", 1).toString()))
        }
    }

    private fun JSONObject.nullableString(key: String): String? = if (!has(key) || isNull(key)) null else optString(key).takeIf { it.isNotBlank() && it != "null" }
    private fun JSONObject.nullableDouble(key: String): Double? = if (!has(key) || isNull(key)) null else optDouble(key).takeIf { !it.isNaN() }
    private inline fun <T> JSONArray.mapObjects(block: (JSONObject) -> T): List<T> = (0 until length()).map { block(getJSONObject(it)) }
}
