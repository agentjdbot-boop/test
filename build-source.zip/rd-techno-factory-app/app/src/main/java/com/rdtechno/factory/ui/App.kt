package com.rdtechno.factory.ui

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.rdtechno.factory.viewmodel.FactoryViewModel

object Routes {
    const val HOME = "home"
    const val OUTWARD_SELECT = "outward/select"
    const val OUTWARD_DETAILS = "outward/details"
    const val OUTWARD_PRODUCTS = "outward/products"
    const val OUTWARD_CART = "outward/cart"
    const val OUTWARD_REVIEW = "outward/review"
    const val OUTWARD_HISTORY = "outward/history"
    const val OUTWARD_VIEW = "outward/view/{id}"
    const val ORDERS = "orders"
    const val ORDER_PRODUCTS = "orders/new/products"
    const val ORDER_CART = "orders/new/cart"
    const val CALCULATOR = "calculator"
    const val PRODUCT_EDITOR = "product/{id}"
    const val MATERIALS = "materials"
    const val MANAGE = "manage"
    const val INVENTORY = "inventory"
    const val LOCATIONS = "locations"
    const val REPORTS = "reports"
    const val DATA = "data"
}

@Composable
fun RDTechnoApp(vm: FactoryViewModel) {
    val nav = rememberNavController()
    NavHost(navController = nav, startDestination = Routes.HOME) {
        composable(Routes.HOME) { HomeScreen(onOutward = { nav.navigate(Routes.OUTWARD_SELECT) }, onCalculator = { nav.navigate(Routes.CALCULATOR) }, onManage = { nav.navigate(Routes.MANAGE) }) }
        composable(Routes.OUTWARD_SELECT) { OutwardSelectScreen(vm, onBack = { nav.popBackStack() }, onContinue = { nav.navigate(Routes.OUTWARD_DETAILS) }, onHistory = { nav.navigate(Routes.OUTWARD_HISTORY) }, onOrders = { nav.navigate(Routes.ORDERS) }, onReports = { nav.navigate(Routes.REPORTS) }, onManageLocations = { nav.navigate(Routes.LOCATIONS) }) }
        composable(Routes.OUTWARD_DETAILS) { OutwardDetailsScreen(vm, onBack = { nav.popBackStack() }, onProducts = { nav.navigate(Routes.OUTWARD_PRODUCTS) }) }
        composable(Routes.OUTWARD_PRODUCTS) { OutwardProductBrowserScreen(vm, onBack = { nav.popBackStack() }, onCart = { nav.navigate(Routes.OUTWARD_CART) }) }
        composable(Routes.OUTWARD_CART) { OutwardCartScreen(vm, onBack = { nav.popBackStack() }, onContinue = { nav.navigate(Routes.OUTWARD_REVIEW) }) }
        composable(Routes.OUTWARD_REVIEW) { OutwardReviewScreen(vm, onBack = { nav.popBackStack() }, onSaved = { id -> nav.navigate("outward/view/$id") { popUpTo(Routes.OUTWARD_SELECT) } }) }
        composable(Routes.OUTWARD_HISTORY) { OutwardHistoryScreen(vm, onBack = { nav.popBackStack() }, onOpen = { nav.navigate("outward/view/$it") }) }
        composable(Routes.OUTWARD_VIEW, arguments = listOf(navArgument("id") { type = NavType.StringType })) { backStack -> OutwardViewScreen(vm, backStack.arguments?.getString("id").orEmpty(), onBack = { nav.popBackStack() }) }
        composable(Routes.ORDERS) { OrdersScreen(vm, onBack = { nav.popBackStack() }, onNew = { vm.startOrder(); nav.navigate(Routes.ORDER_PRODUCTS) }) }
        composable(Routes.ORDER_PRODUCTS) { OrderProductBrowserScreen(vm, onBack = { nav.popBackStack() }, onCart = { nav.navigate(Routes.ORDER_CART) }) }
        composable(Routes.ORDER_CART) { OrderCartScreen(vm, onBack = { nav.popBackStack() }, onSaved = { nav.navigate(Routes.ORDERS) { popUpTo(Routes.ORDERS) { inclusive = true } } }) }
        composable(Routes.CALCULATOR) { CalculatorScreen(vm, onBack = { nav.popBackStack() }, onProduct = { nav.navigate("product/$it") }, onMaterials = { nav.navigate(Routes.MATERIALS) }) }
        composable(Routes.PRODUCT_EDITOR, arguments = listOf(navArgument("id") { type = NavType.StringType })) { backStack -> ProductEditorScreen(vm, backStack.arguments?.getString("id").orEmpty(), onBack = { nav.popBackStack() }) }
        composable(Routes.MATERIALS) { MaterialsScreen(vm, onBack = { nav.popBackStack() }) }
        composable(Routes.MANAGE) { ManageScreen(onBack = { nav.popBackStack() }, onInventory = { nav.navigate(Routes.INVENTORY) }, onMaterials = { nav.navigate(Routes.MATERIALS) }, onLocations = { nav.navigate(Routes.LOCATIONS) }, onData = { nav.navigate(Routes.DATA) }) }
        composable(Routes.INVENTORY) { InventoryScreen(vm, onBack = { nav.popBackStack() }, onProduct = { nav.navigate("product/$it") }, onNewProduct = { nav.navigate("product/new") }) }
        composable(Routes.LOCATIONS) { LocationsScreen(vm, onBack = { nav.popBackStack() }) }
        composable(Routes.REPORTS) { ReportsScreen(vm, onBack = { nav.popBackStack() }) }
        composable(Routes.DATA) { DataScreen(vm, onBack = { nav.popBackStack() }) }
    }
}
