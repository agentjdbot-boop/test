# R D Techno Factory App

Private, offline-first Android application combining the existing R D Techno Outward workflow and Injection Moulding Calculator.

## Version 0.1 test scope

- Native Kotlin + Jetpack Compose Android app
- Room / SQLite local database
- One shared Product Master for Outward, Orders and Calculator
- Initial Plastic Products imported from supplied R D Techno data
- Empty Metal Products category ready for user-managed products
- Add/edit/archive/delete products
- Add/change/remove product images from the Android photo picker
- Location-first Outward workflow with cart quantities and bags
- Historical Outward migration and history browsing
- Order Sheet migration and new order workflow
- Injection-moulding calculator with central Material rates
- Location and Material management
- Offline JSON backup/restore and CSV export
- No Firebase, Google Sheets, Cloudflare, server or internet dependency for daily use

## Historical data seeded

The supplied migration snapshot includes 24 products, 24 local product images, 22 outward records (76 lines), 2 order sheets (19 lines), and current material rates from the supplied Calculator workbook.

## Build

GitHub Actions builds the test APK automatically on `main`. Locally, with Android SDK 35 installed:

```bash
gradle :app:assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`
